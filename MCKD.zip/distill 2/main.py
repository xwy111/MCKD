import os
import torch
import torch.nn as nn
import pandas as pd
import numpy as np
import random
import math
from torch.utils.data import DataLoader
import torch.optim as optim
from utils.dataset import ProteinMoleculeDataset
from utils import protein_init, ligand_init
from models.net import ProteinLigandAffinityModel
import torch.nn.functional as F
from utils.utils import DataLoader, CustomWeightedRandomSampler
import argparse

def set_seed(seed):
    """Set random seed for reproducibility."""
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def drop_invalid_smiles(df, ligand_dict):

    valid_ligands = set(ligand_dict.keys())
    return df[df['Ligand'].isin(valid_ligands)].reset_index(drop=True)


def save_losses(total, distillation, output_path):
    losses = {
        'total_losses': total,
        'distillation_losses': distillation,
    }
    os.makedirs(output_path, exist_ok=True)
    torch.save(losses, os.path.join(output_path, 'losses.pt'))
    print(f"Saved loss history to {output_path}/losses.pt")


def save_checkpoint(model, optimizer, epoch, loss, output_path, filename='checkpoint.pt'):
    os.makedirs(output_path, exist_ok=True)
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'loss': loss,
    }
    torch.save(checkpoint, os.path.join(output_path, filename))
    print(f"Saved checkpoint to {output_path}/{filename}")


def get_lr(args, iter_num):
    if iter_num < args.warmup_iters:
        return args.lrate * iter_num / args.warmup_iters
    elif iter_num > args.lr_decay_iters:
        return args.min_lrate
    else:
        decay_ratio = (iter_num - args.warmup_iters) / (args.lr_decay_iters - args.warmup_iters)
        return args.min_lrate + 0.5 * (1.0 + math.cos(math.pi * decay_ratio)) * (args.lrate - args.min_lrate)

def missing_mse_loss(pred, true, threshold=5.000):
    loss = torch.tensor(0.).to(pred.device)
    if (~torch.isnan(true)).any():
        real_mask = ~torch.isnan(true)
        real_pred = torch.masked_select(pred, real_mask)
        real_true = torch.masked_select(true, real_mask)
        loss = torch.mean((real_true - real_pred) ** 2)

    return loss

def train_model(args, model, train_loader, valid_loader, optimizer):
    device = args.device
    total_losses = []
    distillation_losses = []
    val_losses = []
    regression_weight = 1.0
    best_val_loss = float('inf')
    iter_num = 0
    patience_counter = 0

    print(f"Starting training for {args.epochs} epochs...")
    print(f"Training samples: {len(train_loader.dataset)}")
    if valid_loader:
        print(f"Validation samples: {len(valid_loader.dataset)}")

    for epoch in range(args.epochs):
        model.train()
        epoch_total_loss = 0.0
        epoch_distillation_loss = 0.0
        epoch_reg_loss = 0.0

        for batch_idx, data in enumerate(train_loader):
            if args.schedule_lr:
                curr_lr_rate = get_lr(args, iter_num)
                for param_group in optimizer.param_groups:
                    param_group['lr'] = curr_lr_rate

            data = data.to(device)
            optimizer.zero_grad()
            outputs, distillation_loss = model(
                mol_x=data.mol_x,
                mol_x_feat=data.mol_x_feat,
                bond_x=data.mol_edge_attr,
                atom_edge_index=data.mol_edge_index,
                residue_x=data.prot_node_aa,
                residue_evo_x=data.prot_node_evo,
                residue_edge_index=data.prot_edge_index,
                residue_edge_weight=data.prot_edge_weight,
                mol_batch=data.mol_x_batch,
                prot_batch=data.prot_node_aa_batch,
            )
            reg_loss = torch.tensor(0.0, device=device)
            if hasattr(data, 'reg_y') and data.reg_y is not None:
                reg_pred = outputs['regression'].squeeze()
                reg_y = data.reg_y.squeeze()
                reg_loss = missing_mse_loss(reg_pred, reg_y) * regression_weight

            loss = reg_loss + args.distillation_weight * distillation_loss
            loss.backward()
            if args.grad_clip > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)

            optimizer.step()
            epoch_total_loss += loss.item()
            epoch_distillation_loss += distillation_loss.item()
            epoch_reg_loss += reg_loss.item()
            iter_num += 1

            if (batch_idx + 1) % args.log_interval == 0:
                curr_lr = optimizer.param_groups[0]['lr']
                print(f"Epoch {epoch + 1}/{args.epochs} | Batch {batch_idx + 1}/{len(train_loader)} | "
                      f"Loss: {loss.item():.4f} | Reg: {reg_loss.item():.4f} | "
                      f"Distill: {distillation_loss.item():.4f} | LR: {curr_lr:.6f}")

        avg_total_loss = epoch_total_loss / len(train_loader)
        avg_distillation_loss = epoch_distillation_loss / len(train_loader)
        avg_reg_loss = epoch_reg_loss / len(train_loader)

        total_losses.append(avg_total_loss)
        distillation_losses.append(avg_distillation_loss)

        print(f"\n{'=' * 60}")
        print(f"Epoch {epoch + 1}/{args.epochs} Summary:")
        print(f"  Avg Total Loss: {avg_total_loss:.4f}")
        print(f"  Avg Regression Loss: {avg_reg_loss:.4f}")
        print(f"  Avg Distillation Loss: {avg_distillation_loss:.4f}")

        if valid_loader:
            model.eval()
            val_total_loss = 0.0
            val_reg_loss = 0.0
            val_distill_loss = 0.0

            with torch.no_grad():
                for data in valid_loader:
                    data = data.to(device)
                    outputs, distillation_loss = model(
                        mol_x=data.mol_x,
                        mol_x_feat=data.mol_x_feat,
                        bond_x=data.mol_edge_attr,
                        atom_edge_index=data.mol_edge_index,
                        residue_x=data.prot_node_aa,
                        residue_evo_x=data.prot_node_evo,
                        residue_edge_index=data.prot_edge_index,
                        residue_edge_weight=data.prot_edge_weight,
                        mol_batch=data.mol_x_batch,
                        prot_batch=data.prot_node_aa_batch,
                    )

                    reg_loss = torch.tensor(0.0, device=device)
                    if hasattr(data, 'reg_y') and data.reg_y is not None:
                        reg_pred = outputs['regression'].squeeze()
                        reg_y = data.reg_y.squeeze()
                        reg_loss = missing_mse_loss(reg_pred, reg_y) * regression_weight
                    val_reg_loss += reg_loss.item()
                    val_distill_loss += distillation_loss.item()
                    val_total_loss += (reg_loss + args.distillation_weight * distillation_loss).item()

            val_total_loss /= len(valid_loader)
            val_reg_loss /= len(valid_loader)
            val_distill_loss /= len(valid_loader)
            val_losses.append(val_total_loss)

            print(f"  Validation Loss: {val_total_loss:.4f}")
            print(f"  Validation Reg Loss: {val_reg_loss:.4f}")
            print(f"  Validation Distill Loss: {val_distill_loss:.4f}")

            if val_total_loss < best_val_loss:
                best_val_loss = val_total_loss
                patience_counter = 0
                save_checkpoint(model, optimizer, epoch, val_total_loss, args.output_path,
                                filename='best_model.pt')
                print(f"  ✓ New best validation loss: {best_val_loss:.4f}")
            else:
                patience_counter += 1
                print(f"  No improvement. Patience: {patience_counter}/{args.patience}")

            # Early stopping
            if args.early_stop and patience_counter >= args.patience:
                print(f"\nEarly stopping triggered after {epoch + 1} epochs!")
                break
        print(f"{'=' * 60}\n")
        if (epoch + 1) % args.save_interval == 0:
            save_checkpoint(model, optimizer, epoch, avg_total_loss, args.output_path,
                            filename=f'checkpoint_epoch_{epoch + 1}.pt')
    save_checkpoint(model, optimizer, args.epochs, avg_total_loss, args.output_path,
                    filename='final_model.pt')
    save_losses(total_losses, distillation_losses, args.output_path)
    if valid_loader:
        torch.save({'val_losses': val_losses}, os.path.join(args.output_path, 'val_losses.pt'))
    print("\n" + "=" * 60)
    print("Training completed!")
    print(f"Best validation loss: {best_val_loss:.4f}")
    print(f"Models saved to: {args.output_path}")
    print("=" * 60)


def test_model(args, model, test_loader):

    device = args.device
    model.eval()

    all_preds = []
    all_targets = []
    test_loss = 0.0

    print("\nTesting the model...")
    with torch.no_grad():
        for batch_idx, data in enumerate(test_loader):
            data = data.to(device)

            # Forward pass - 只返回两个值
            outputs, _ = model(
                mol_x=data.mol_x,
                mol_x_feat=data.mol_x_feat,
                bond_x=data.mol_edge_attr,
                atom_edge_index=data.mol_edge_index,
                residue_x=data.prot_node_aa,
                residue_evo_x=data.prot_node_evo,
                residue_edge_index=data.prot_edge_index,
                residue_edge_weight=data.prot_edge_weight,
                mol_batch=data.mol_x_batch,
                prot_batch=data.prot_node_aa_batch,
            )

            pred = outputs['regression'].squeeze()

            if hasattr(data, 'reg_y') and data.reg_y is not None:
                target = data.reg_y.squeeze()
                loss = missing_mse_loss(pred, target)
                test_loss += loss.item()

                # Collect predictions and targets
                mask = ~torch.isnan(target)
                all_preds.extend(pred[mask].cpu().numpy())
                all_targets.extend(target[mask].cpu().numpy())

            if (batch_idx + 1) % 10 == 0:
                print(f"Test Batch {batch_idx + 1}/{len(test_loader)}")

    # Calculate metrics
    if all_preds:
        all_preds = np.array(all_preds)
        all_targets = np.array(all_targets)

        mse = np.mean((all_preds - all_targets) ** 2)
        rmse = np.sqrt(mse)
        mae = np.mean(np.abs(all_preds - all_targets))

        # Pearson correlation
        pearson_corr = np.corrcoef(all_preds, all_targets)[0, 1]

        print("\n" + "=" * 60)
        print("Test Results:")
        print(f"  MSE:  {mse:.4f}")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  MAE:  {mae:.4f}")
        print(f"  Pearson R: {pearson_corr:.4f}")
        print("=" * 60)

        # Save predictions
        results = pd.DataFrame({
            'prediction': all_preds,
            'target': all_targets
        })
        results.to_csv(os.path.join(args.output_path, 'test_predictions.csv'), index=False)
        print(f"Predictions saved to {args.output_path}/test_predictions.csv")


def main(args):
    # Set random seed
    set_seed(args.seed)

    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    args.device = device
    print(f"Using device: {device}")

    # Load data
    print("\nLoading data...")
    train_df = pd.read_csv(os.path.join(args.datafolder, 'train.csv'))
    test_df = pd.read_csv(os.path.join(args.datafolder, 'test.csv'))
    valid_path = os.path.join(args.datafolder, 'valid.csv')
    valid_df = pd.read_csv(valid_path) if os.path.exists(valid_path) else None

    print(f"Train samples: {len(train_df)}")
    print(f"Test samples: {len(test_df)}")
    if valid_df is not None:
        print(f"Valid samples: {len(valid_df)}")

    # Initialize or load graph data
    protein_path = os.path.join(args.datafolder, 'protein.pt')
    ligand_path = os.path.join(args.datafolder, 'ligand.pt')

    print("\nInitializing protein and ligand data...")
    if os.path.exists(protein_path):
        protein_dict = torch.load(protein_path)
        print(f"Loaded {len(protein_dict)} proteins from {protein_path}")
    else:
        protein_seqs = list(set(train_df['Protein']) | set(test_df['Protein']) |
                            set(valid_df['Protein'] if valid_df is not None else []))
        protein_dict = protein_init(protein_seqs)
        torch.save(protein_dict, protein_path)
        print(f"Initialized and saved {len(protein_dict)} proteins")

    if os.path.exists(ligand_path):
        ligand_dict = torch.load(ligand_path)
        print(f"Loaded {len(ligand_dict)} ligands from {ligand_path}")
    else:
        ligand_smiles = list(set(train_df['Ligand']) | set(test_df['Ligand']) |
                             set(valid_df['Ligand'] if valid_df is not None else []))
        ligand_dict = ligand_init(ligand_smiles)
        torch.save(ligand_dict, ligand_path)
        print(f"Initialized and saved {len(ligand_dict)} ligands")

    # Drop invalid SMILES
    train_df = drop_invalid_smiles(train_df, ligand_dict)
    test_df = drop_invalid_smiles(test_df, ligand_dict)
    if valid_df is not None:
        valid_df = drop_invalid_smiles(valid_df, ligand_dict)

    # Training sampler
    train_shuffle = True
    train_sampler = None

    if args.sampling_col:
        train_weights = torch.from_numpy(train_df[args.sampling_col].values)
        train_sampler = CustomWeightedRandomSampler(train_weights, len(train_weights), replacement=True)
        train_shuffle = False
        print(f"Using weighted sampling based on column: {args.sampling_col}")

    # Create data loaders
    print("\nCreating data loaders...")
    train_dataset = ProteinMoleculeDataset(train_df, ligand_dict, protein_dict, device=args.device)
    test_dataset = ProteinMoleculeDataset(test_df, ligand_dict, protein_dict, device=args.device)

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=train_shuffle,
        sampler=train_sampler,
        follow_batch=['mol_x', 'clique_x', 'prot_node_aa']
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        follow_batch=['mol_x', 'clique_x', 'prot_node_aa']
    )

    valid_loader = None
    if valid_df is not None:
        valid_dataset = ProteinMoleculeDataset(valid_df, ligand_dict, protein_dict, device=args.device)
        valid_loader = DataLoader(
            valid_dataset,
            batch_size=args.batch_size,
            shuffle=False,
            follow_batch=['mol_x', 'clique_x', 'prot_node_aa']
        )

    # Initialize model
    print("\nInitializing model...")
    model = ProteinLigandAffinityModel(
        mol_in_channels=43,
        prot_in_channels=33,
        prot_evo_channels=1280,
        hidden_channels=200,
        total_layer=3,
        heads=4,
        dropout=0.1,
        num_ban_projections=4,
        use_multihead_ban=True,
        ban_num_heads=4,
        regression_head=True,
        classification_head=False,
        multiclassification_head=False,
        device=args.device
    ).to(args.device)

    # Count parameters
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Total parameters: {total_params:,}")
    print(f"Trainable parameters: {trainable_params:,}")

    # Initialize optimizer
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lrate, weight_decay=args.weight_decay)

    # Calculate lr decay iters
    if args.schedule_lr:
        args.lr_decay_iters = args.epochs * len(train_loader)
        print(f"\nLR scheduling enabled:")
        print(f"  Warmup iters: {args.warmup_iters}")
        print(f"  Decay iters: {args.lr_decay_iters}")
        print(f"  Min LR: {args.min_lrate}")

    train_model(args, model, train_loader, valid_loader, optimizer)
    test_model(args, model, test_loader)


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='Train Protein-Ligand Affinity Model')
    parser.add_argument('--datafolder', type=str, default='./dataset/pdb2020',help='Path to dataset folder')
    parser.add_argument('--sampling_col', type=str, default='',help='Column name for weighted sampling')
    parser.add_argument('--device', type=str, default='cuda:0',help='Device to run the model on')
    parser.add_argument('--batch_size', type=int, default=16, help='Batch size')
    parser.add_argument('--epochs', type=int, default=100, help='Number of epochs')
    parser.add_argument('--lrate', type=float, default=1e-3, help='Initial learning rate')
    parser.add_argument('--min_lrate', type=float, default=1e-6, help='Minimum learning rate')
    parser.add_argument('--weight_decay', type=float, default=0.0, help='Weight decay')
    parser.add_argument('--grad_clip', type=float, default=1.0, help='Gradient clipping (0 to disable)')
    parser.add_argument('--distillation_weight', type=float, default=0.1,
                        help='Weight for distillation loss')
    parser.add_argument('--schedule_lr', action='store_true', help='Enable LR scheduling')
    parser.add_argument('--warmup_iters', type=int, default=2000, help='Warmup iterations')
    parser.add_argument('--early_stop', action='store_true', help='Enable early stopping')
    parser.add_argument('--patience', type=int, default=10, help='Patience for early stopping')
    parser.add_argument('--output_path', type=str, default='./result/PDB2020_BENCHMARK/',
                        help='Path to save outputs')
    parser.add_argument('--log_interval', type=int, default=50, help='Log every N batches')
    parser.add_argument('--save_interval', type=int, default=10, help='Save checkpoint every N epochs')
    parser.add_argument('--seed', type=int, default=42, help='Random seed')

    args = parser.parse_args()

    main(args)