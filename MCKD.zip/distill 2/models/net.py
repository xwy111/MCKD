import torch
import torch.nn as nn
import torch.nn.functional as F
import torch_geometric
from torch.nn import Embedding, Linear
from torch_geometric.nn import GCNConv, GlobalAttention, global_add_pool, global_max_pool, global_mean_pool
from torch_geometric.nn import AttentionalAggregation
from torch_geometric.utils import softmax, degree
from torch_scatter import scatter
from torch_geometric.nn.norm import GraphNorm
import math
from models.layers import MLP, PosLinear
from models.GNN import Protein_GNN



class BilinearAttentionNetwork(nn.Module):

    def __init__(self, ligand_dim, protein_dim, hidden_dim, num_projections=4, dropout=0.1):
        super(BilinearAttentionNetwork, self).__init__()

        self.ligand_dim = ligand_dim
        self.protein_dim = protein_dim
        self.hidden_dim = hidden_dim
        self.num_projections = num_projections
        self.ligand_projections = nn.ModuleList([
            nn.Linear(ligand_dim, hidden_dim, bias=False)
            for _ in range(num_projections)
        ])

        self.protein_projections = nn.ModuleList([
            nn.Linear(protein_dim, hidden_dim, bias=False)
            for _ in range(num_projections)
        ])
        self.weight_vector = nn.Parameter(torch.randn(hidden_dim))
        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(num_projections * hidden_dim)
        self.temperature = nn.Parameter(torch.ones(1))
        self.reset_parameters()

    def reset_parameters(self):

        for proj in self.ligand_projections:
            nn.init.xavier_uniform_(proj.weight)
        for proj in self.protein_projections:
            nn.init.xavier_uniform_(proj.weight)
        nn.init.normal_(self.weight_vector, std=0.02)
        nn.init.constant_(self.temperature, 1.0)

    def compute_interaction_map(self, ligand_features, protein_features):

        N_atoms = ligand_features.size(0)
        N_residues = protein_features.size(0)
        ligand_proj = torch.tanh(self.ligand_projections[0](ligand_features))
        protein_proj = torch.tanh(self.protein_projections[0](protein_features))
        elementwise_product = ligand_proj.unsqueeze(1) * protein_proj.unsqueeze(0)
        interaction_map = torch.einsum('ijk,k->ij', elementwise_product, self.weight_vector)
        interaction_map = interaction_map / self.temperature
        return interaction_map

    def bilinear_pooling(self, ligand_features, protein_features, interaction_map):

        pooled_features_list = []

        for k in range(self.num_projections):

            ligand_proj = torch.tanh(self.ligand_projections[k](ligand_features))
            protein_proj = torch.tanh(self.protein_projections[k](protein_features))
            weighted_protein = torch.matmul(interaction_map, protein_proj)
            pooled = torch.sum(ligand_proj * weighted_protein, dim=0)
            pooled_features_list.append(pooled)
        pooled_features = torch.cat(pooled_features_list, dim=0)

        return pooled_features

    def forward(self, ligand_features, protein_features, ligand_batch, protein_batch):

        batch_size = ligand_batch.max().item() + 1
        joint_features_list = []
        interaction_maps_list = []

        for batch_idx in range(batch_size):

            ligand_mask = (ligand_batch == batch_idx)
            protein_mask = (protein_batch == batch_idx)
            ligand_feats = ligand_features[ligand_mask]  # [N_atoms_i, d_a]
            protein_feats = protein_features[protein_mask]  # [N_residues_i, d_p]
            interaction_map = self.compute_interaction_map(ligand_feats, protein_feats)
            interaction_maps_list.append(interaction_map)
            pooled_feats = self.bilinear_pooling(ligand_feats, protein_feats, interaction_map)
            joint_features_list.append(pooled_feats)
        joint_features = torch.stack(joint_features_list, dim=0)

        # Apply normalization and dropout
        joint_features = self.layer_norm(joint_features)
        joint_features = self.dropout(joint_features)

        return joint_features, interaction_maps_list


class MultiHeadBilinearAttention(nn.Module):

    def __init__(self, ligand_dim, protein_dim, hidden_dim, num_heads=4,
                 num_projections=4, dropout=0.1):
        super(MultiHeadBilinearAttention, self).__init__()

        self.num_heads = num_heads
        self.hidden_dim = hidden_dim

        # Multiple BAN heads
        self.ban_heads = nn.ModuleList([
            BilinearAttentionNetwork(
                ligand_dim, protein_dim, hidden_dim, num_projections, dropout
            )
            for _ in range(num_heads)
        ])

        # Output projection
        self.output_projection = nn.Linear(
            num_heads * num_projections * hidden_dim,
            hidden_dim * num_projections
        )

        self.layer_norm = nn.LayerNorm(hidden_dim * num_projections)
        self.dropout = nn.Dropout(dropout)

    def reset_parameters(self):
        """Initialize parameters"""
        for head in self.ban_heads:
            head.reset_parameters()
        nn.init.xavier_uniform_(self.output_projection.weight)
        if self.output_projection.bias is not None:
            nn.init.zeros_(self.output_projection.bias)

    def forward(self, ligand_features, protein_features, ligand_batch, protein_batch):

        head_outputs = []
        all_interaction_maps = []

        for head in self.ban_heads:
            joint_feats, interaction_maps = head(
                ligand_features, protein_features, ligand_batch, protein_batch
            )
            head_outputs.append(joint_feats)
            all_interaction_maps.append(interaction_maps)

        concat_features = torch.cat(head_outputs, dim=-1)

        joint_features = self.output_projection(concat_features)
        joint_features = self.layer_norm(joint_features)
        joint_features = self.dropout(joint_features)

        return joint_features, all_interaction_maps


# ===========================
# Distillation Module
# ===========================

class DistillationModule(nn.Module):
    """
    Improved distillation module with progressive layer-wise distillation.
    """

    def __init__(self, input_dim, output_dim, alpha=0.7):
        super(DistillationModule, self).__init__()
        self.alpha = alpha
        self.input_proj = nn.Linear(input_dim, output_dim)
        self.distill_loss_fn_output = nn.MSELoss()
        self.distill_loss_fn_attention = nn.MSELoss()

    def compute_output_distillation_loss(self, input_features, output_features):
        """Distill input to output"""
        input_proj = self.input_proj(input_features)
        return self.distill_loss_fn_output(output_features, input_proj)

    def select_highest_mse_matrices(self, attention_matrices):
        """Select most representative attention head from each layer"""
        selected_matrices = []
        for layer in attention_matrices:
            mean_matrix = layer.mean(dim=0)
            mean_matrix = mean_matrix / (mean_matrix.norm(p=2, dim=-1, keepdim=True) + 1e-8)
            mse_values = [self.distill_loss_fn_attention(head, mean_matrix).item() for head in layer]
            max_mse_idx = torch.argmax(torch.tensor(mse_values))
            selected_matrices.append(layer[max_mse_idx])
        return selected_matrices

    def compute_attention_distillation_loss(self, attention_matrices):
        """Progressive layer-wise attention distillation"""
        selected_matrices = self.select_highest_mse_matrices(attention_matrices)
        attention_loss = 0
        # Progressive distillation: each layer learns from previous layer
        for i in range(1, len(selected_matrices)):
            attention_loss += self.distill_loss_fn_attention(
                selected_matrices[i],
                selected_matrices[i - 1].detach()  # Detach to avoid gradient flow
            )
        return attention_loss

    def forward(self, input_features, output_features, attention_matrices):
        output_loss = self.compute_output_distillation_loss(input_features, output_features)
        attention_loss = self.compute_attention_distillation_loss(attention_matrices)
        total_loss = self.alpha * output_loss + (1 - self.alpha) * attention_loss
        return total_loss

class MultiHeadAttentionLayer(nn.Module):


    def __init__(self, in_dim, out_dim, num_heads, use_bias=True, dropout=0.1):
        super(MultiHeadAttentionLayer, self).__init__()
        self.num_heads = num_heads
        self.head_dim = out_dim // num_heads
        self.out_dim = out_dim

        self.Q = nn.Linear(in_dim, out_dim, bias=use_bias)
        self.K = nn.Linear(in_dim, out_dim, bias=use_bias)
        self.V = nn.Linear(in_dim, out_dim, bias=use_bias)
        self.edge_proj = nn.Linear(out_dim, out_dim, bias=use_bias)
        self.proj = nn.Linear(out_dim, out_dim)
        self.dropout = nn.Dropout(dropout)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.Q.weight)
        nn.init.xavier_uniform_(self.K.weight)
        nn.init.xavier_uniform_(self.V.weight)
        nn.init.xavier_uniform_(self.edge_proj.weight)
        nn.init.xavier_uniform_(self.proj.weight)

    def forward(self, x, edge_index, edge_attr):

        device = x.device
        num_nodes = x.size(0)
        Q = self.Q(x).view(-1, self.num_heads, self.head_dim)  # [num_nodes, num_heads, head_dim]
        K = self.K(x).view(-1, self.num_heads, self.head_dim)
        V = self.V(x).view(-1, self.num_heads, self.head_dim)

        edge_attr = edge_attr.float()
        edge_attr = self.edge_proj(edge_attr)
        edge_attr = edge_attr.view(-1, self.num_heads, self.head_dim)

        row, col = edge_index
        alpha = (Q[row] * K[col] + edge_attr).sum(dim=-1) / (self.head_dim ** 0.5)
        alpha = softmax(alpha, row, num_nodes=num_nodes)
        alpha = self.dropout(alpha)
        edge_out = alpha.unsqueeze(-1) * V[col]
        node_out = scatter(edge_out, row, dim=0, reduce="sum", dim_size=num_nodes)
        out = node_out.view(-1, self.out_dim)
        out = self.proj(out)
        attention_matrix = torch.zeros(num_nodes, num_nodes, self.num_heads, device=device)
        attention_matrix[row, col] = alpha

        return out, attention_matrix


class PositionwiseFeedForward(nn.Module):

    def __init__(self, d_model, d_ff, dropout=0.1):
        super(PositionwiseFeedForward, self).__init__()
        self.fc1 = nn.Linear(d_model, d_ff)
        self.fc2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.GELU()

    def forward(self, x):
        return self.fc2(self.dropout(self.activation(self.fc1(x))))


class GraphTransformerLayer(nn.Module):
    def __init__(self, in_dim, out_dim, num_heads, dropout=0.2, residual=True, layer_norm=True):
        super(GraphTransformerLayer, self).__init__()
        self.attn = MultiHeadAttentionLayer(in_dim, out_dim, num_heads, dropout=dropout)
        self.positionwise_feedforward = PositionwiseFeedForward(out_dim, d_ff=4 * out_dim, dropout=dropout)
        self.residual = residual
        self.norm1 = nn.LayerNorm(out_dim) if layer_norm else nn.Identity()
        self.norm2 = nn.LayerNorm(out_dim) if layer_norm else nn.Identity()
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.bond_encoder = nn.Embedding(5, out_dim)

    def reset_parameters(self):
        self.attn.reset_parameters()
        nn.init.ones_(self.norm1.weight)
        nn.init.zeros_(self.norm1.bias)
        nn.init.ones_(self.norm2.weight)
        nn.init.zeros_(self.norm2.bias)
        self.bond_encoder.reset_parameters()

    def forward(self, node_x, edge_attr, edge_index):

        residual = node_x

        # Encode edge features
        edge_attr = self.bond_encoder(edge_attr.squeeze())

        node_x, attn_weights = self.attn(node_x, edge_index, edge_attr)
        node_x = self.dropout1(node_x)
        if self.residual:
            node_x = self.norm1(node_x + residual)
        else:
            node_x = self.norm1(node_x)

        residual = node_x
        node_x = self.positionwise_feedforward(node_x)
        node_x = self.dropout2(node_x)
        if self.residual:
            node_x = self.norm2(node_x + residual)
        else:
            node_x = self.norm2(node_x)

        return node_x, attn_weights



class ProteinLigandAffinityModel(nn.Module):
    def __init__(
            self,
            mol_in_channels,
            prot_in_channels,
            prot_evo_channels,
            hidden_channels,
            total_layer,
            heads,
            dropout,
            num_ban_projections=4,
            use_multihead_ban=True,
            ban_num_heads=4,
            regression_head=True,
            classification_head=False,
            multiclassification_head=False,
            device='cuda:0',
    ):
        super(ProteinLigandAffinityModel, self).__init__()

        self.regression_head = regression_head
        self.classification_head = classification_head
        self.multiclassification_head = multiclassification_head
        self.device = device

        # === Ligand Encoder ===
        self.atom_encoder = Embedding(20, hidden_channels)
        self.atom_feat_encoder = MLP([mol_in_channels, hidden_channels * 2, hidden_channels], out_norm=True)
        self.prot_edge_dim = hidden_channels

        # Graph Transformer layers for ligand
        self.atom_layers = nn.ModuleList([
            GraphTransformerLayer(hidden_channels, hidden_channels, heads, dropout=dropout)
            for _ in range(total_layer)
        ])

        self.mol_gn = GraphNorm(hidden_channels)

        # === Protein Encoder ===
        self.prot_evo = MLP([prot_evo_channels, hidden_channels * 2, hidden_channels], out_norm=True)
        self.prot_aa = MLP([prot_in_channels, hidden_channels * 2, hidden_channels], out_norm=True)
        self.residue_gnn = Protein_GNN(hidden_channels, hidden_channels, dropout)
        self.prot_gn = GraphNorm(hidden_channels)

        # === Bilinear Attention Network ===
        if use_multihead_ban:
            self.ban = MultiHeadBilinearAttention(
                ligand_dim=hidden_channels,
                protein_dim=hidden_channels,
                hidden_dim=hidden_channels // ban_num_heads,
                num_heads=ban_num_heads,
                num_projections=num_ban_projections,
                dropout=dropout
            )
            ban_output_dim = (hidden_channels // ban_num_heads) * num_ban_projections
        else:
            self.ban = BilinearAttentionNetwork(
                ligand_dim=hidden_channels,
                protein_dim=hidden_channels,
                hidden_dim=hidden_channels,
                num_projections=num_ban_projections,
                dropout=dropout
            )
            ban_output_dim = num_ban_projections * hidden_channels

        # === Task Heads ===
        if self.regression_head:
            self.reg_out = MLP([ban_output_dim, hidden_channels, 1])
        if self.classification_head:
            self.cls_out = MLP([ban_output_dim, hidden_channels, 1])
        if self.multiclassification_head:
            self.mcls_out = MLP([ban_output_dim, hidden_channels, multiclassification_head])

        # === Distillation Module ===
        self.distillation_module = DistillationModule(hidden_channels, hidden_channels)

    def reset_parameters(self):
        """Reset all parameters"""
        self.atom_feat_encoder.reset_parameters()
        self.prot_evo.reset_parameters()
        self.prot_aa.reset_parameters()

        for layer in self.atom_layers:
            layer.reset_parameters()

        self.ban.reset_parameters()

        if self.regression_head:
            self.reg_out.reset_parameters()
        if self.classification_head:
            self.cls_out.reset_parameters()
        if self.multiclassification_head:
            self.mcls_out.reset_parameters()

    def forward(self, mol_x, mol_x_feat, bond_x, atom_edge_index,
                residue_x, residue_evo_x,
                residue_edge_index, residue_edge_weight,
                mol_batch, prot_batch):

        mol_x = self.atom_encoder(mol_x.squeeze()) + self.atom_feat_encoder(mol_x_feat)

        atom_intermediate_outputs = []
        atom_attention_matrices = []

        for layer in self.atom_layers:
            mol_x, attn_weights = layer(mol_x, bond_x, atom_edge_index)
            atom_intermediate_outputs.append(mol_x)
            atom_attention_matrices.append(attn_weights)

        mol_x = self.mol_gn(mol_x, mol_batch)  # [total_atoms, hidden_channels]

        # === Encode Protein ===
        residue_edge_attr = _rbf(
            residue_edge_weight,
            D_max=1.0,
            D_count=self.prot_edge_dim,
            device=self.device
        )

        residue_x = self.prot_aa(residue_x) + self.prot_evo(residue_evo_x)
        residue_x = self.residue_gnn(residue_x, residue_edge_index, residue_edge_attr)
        residue_x = self.prot_gn(residue_x, prot_batch)  # [total_residues, hidden_channels]

        # === Bilinear Attention Fusion ===
        joint_features, interaction_maps = self.ban(
            ligand_features=mol_x,
            protein_features=residue_x,
            ligand_batch=mol_batch,
            protein_batch=prot_batch
        )
        # joint_features: [batch_size, ban_output_dim]

        # === Task Predictions ===
        outputs = {}

        if self.regression_head:
            outputs['regression'] = self.reg_out(joint_features)
        if self.classification_head:
            outputs['classification'] = self.cls_out(joint_features)
        if self.multiclassification_head:
            outputs['multiclass'] = self.mcls_out(joint_features)

        # === Distillation Loss ===
        distillation_loss = self.distillation_module(
            atom_intermediate_outputs[0],
            atom_intermediate_outputs[-1],
            atom_attention_matrices
        )

        return outputs, distillation_loss, interaction_maps

    def configure_optimizers(self, weight_decay, learning_rate, betas, eps, amsgrad):
        """Configure optimizer with proper weight decay"""
        whitelist_weight_modules = (torch.nn.Linear, torch_geometric.nn.dense.linear.Linear)
        blacklist_weight_modules = (torch.nn.LayerNorm, torch.nn.Embedding, GraphNorm, PosLinear)

        decay = set()
        no_decay = set()

        for module_name, module in self.named_modules():
            for param_name, param in module.named_parameters(recurse=False):
                full_param_name = f"{module_name}.{param_name}" if module_name else param_name

                if param_name.endswith("bias") or param_name.endswith("mean_scale"):
                    no_decay.add(full_param_name)
                elif param_name.endswith("weight"):
                    if isinstance(module, whitelist_weight_modules):
                        decay.add(full_param_name)
                    elif isinstance(module, blacklist_weight_modules):
                        no_decay.add(full_param_name)

        param_dict = {name: param for name, param in self.named_parameters()}
        all_params = set(param_dict.keys())
        inter_params = decay & no_decay
        unclassified_params = all_params - (decay | no_decay)

        assert len(inter_params) == 0, f"Parameters {inter_params} in both decay/no_decay!"
        assert len(unclassified_params) == 0, f"Parameters {unclassified_params} not classified!"

        optim_groups = [
            {"params": [param_dict[name] for name in sorted(decay)], "weight_decay": weight_decay},
            {"params": [param_dict[name] for name in sorted(no_decay)], "weight_decay": 0.0},
        ]

        optimizer = torch.optim.AdamW(optim_groups, lr=learning_rate, betas=betas, eps=eps, amsgrad=amsgrad)
        return optimizer


def _rbf(D, D_min=0., D_max=1., D_count=16, device='cpu'):
    """Radial basis function for encoding distance features"""
    D = torch.where(D < D_max, D, torch.tensor(D_max).float().to(device))
    D_mu = torch.linspace(D_min, D_max, D_count, device=device)
    D_mu = D_mu.view([1, -1])
    D_sigma = (D_max - D_min) / D_count
    D_expand = torch.unsqueeze(D, -1)
    RBF = torch.exp(-((D_expand - D_mu) / D_sigma) ** 2)
    return RBF