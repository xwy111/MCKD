import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv

class Protein_GNN(nn.Module):
    def __init__(self, hidden_channels, edge_channels, dropout=0.1):
        super(Protein_GNN, self).__init__()

        # Define GNN layers using SAGEConv to utilize edge features
        self.conv1 = SAGEConv(
            in_channels=hidden_channels,
            out_channels=hidden_channels
        )
        self.conv2 = SAGEConv(
            in_channels=hidden_channels,
            out_channels=hidden_channels
        )
        self.conv3 = SAGEConv(
            in_channels=hidden_channels,
            out_channels=hidden_channels
        )

        self.norm1 = nn.LayerNorm(hidden_channels)
        self.norm2 = nn.LayerNorm(hidden_channels)
        self.norm3 = nn.LayerNorm(hidden_channels)

        self.edge_proj = nn.Linear(edge_channels, hidden_channels)
        self.dropout = dropout

    def reset_parameters(self):
        self.conv1.reset_parameters()
        self.conv2.reset_parameters()
        self.conv3.reset_parameters()
        self.norm1.reset_parameters()
        self.norm2.reset_parameters()
        self.norm3.reset_parameters()
        self.edge_proj.reset_parameters()

    def forward(self, residue_x, residue_edge_index, residue_edge_weight):
        # Project edge features to match node feature dimensions
        edge_attr = self.edge_proj(residue_edge_weight)

        # First SAGE layer with edge_attr integration, normalization, and activation
        x_in = residue_x
        x = self.conv1(residue_x, residue_edge_index)
        x = x + edge_attr.sum(dim=0, keepdim=True)  # Aggregate edge attributes
        x = F.relu(self.norm1(x))
        x = F.dropout(x, self.dropout, training=self.training)

        # Second SAGE layer with normalization
        x = self.conv2(x, residue_edge_index)
        x = x + edge_attr.sum(dim=0, keepdim=True)  # Aggregate edge attributes
        x = F.relu(self.norm2(x))
        x = F.dropout(x, self.dropout, training=self.training)

        # Third SAGE layer with normalization and residual connection
        x = self.conv3(x, residue_edge_index)
        x = x + edge_attr.sum(dim=0, keepdim=True)  # Aggregate edge attributes
        x = F.relu(self.norm3(x + x_in))  # Residual connection
        x = F.dropout(x, self.dropout, training=self.training)

        return x
